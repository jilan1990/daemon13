package timespace.utils;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.fastjson.JSON;

public class NoticeMessageUdpUtil {

    public static void sendNoticeMessage(String params, String openid, String title) {

        Map<String, String> map = new HashMap<String, String>();
        map.put("params", params);
        map.put("openid", openid);
        map.put("title", title);

        String data = JSON.toJSONString(map);
        System.out.println(data);

        byte[] bytes = data.getBytes();

        try (DatagramSocket socket = new DatagramSocket();) {
            InetAddress address = InetAddress.getByName("www.corrine.com.cn");
            int port = 6687;
            DatagramPacket packet = new DatagramPacket(bytes, bytes.length, address, port);

            socket.send(packet);
        } catch (SocketException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
