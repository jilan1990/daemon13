package timespace.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import timespace.publicnumber.PNUnionIDMaster;
import timespace.publicnumber.PublicNumberAccessTokenRedis;

public class NoticeMessageUtil {
    private final static String TEMPLATE_ID = "ozRbQUou1WV2ZHOQwu0YXI_HR8GLUU12N0Zl3JuUOjw";

    public static void sendNoticeMessage(String unionid, String title, String msg) {

        String accessToken = PublicNumberAccessTokenRedis.getInstance().getAccessToken();

        String openid = PNUnionIDMaster.getInstance().getOpenIDByUnionID(unionid);
        if (openid == null) {
            System.out.println("sendNoticeMessage failed, openid==ull");
            return;
        }

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://www.corrine.com.cn:8090").path("cgi-bin/message/template/send");

        Map<String, Object> jsonMap = new HashMap<String, Object>();
        jsonMap.put("touser", openid);
        jsonMap.put("template_id", TEMPLATE_ID);
        jsonMap.put("url", "http://www.daemon13.com?openid=" + openid);
        jsonMap.put("topcolor", "#FF0000");

        Map<String, Object> data = new HashMap<String, Object>();

        Map<String, Object> first = new HashMap<String, Object>();
        first.put("value", title);
        first.put("color", "#173177");
        data.put("first", first);

        Map<String, Object> keyword1 = new HashMap<String, Object>();
        keyword1.put("value", "一份期许");
        keyword1.put("color", "#173177");
        data.put("keyword1", keyword1);

        Map<String, Object> keyword2 = new HashMap<String, Object>();
        keyword2.put("value", String.valueOf(new Date()));
        keyword2.put("color", "#173177");
        data.put("keyword2", keyword2);

        Map<String, Object> remark = new HashMap<String, Object>();
        remark.put("value", msg);
        remark.put("color", "#173177");
        data.put("remark", remark);

        jsonMap.put("data", data);

        String bean = target.queryParam("access_token", accessToken).request(MediaType.APPLICATION_JSON_TYPE)
                .post(Entity.entity(jsonMap, MediaType.APPLICATION_JSON), String.class);

        System.out.println(bean);
    }
}
