package timespace.publicnumber;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.Response;

import org.glassfish.json.JsonUtil;

public class PublicNumberAccessToken0 {

    private static final PublicNumberAccessToken0 INSTANCE = new PublicNumberAccessToken0();

    private PublicNumberAccessToken0() {
    }

    public static PublicNumberAccessToken0 getInstance() {
        return INSTANCE;
    }

    private static String grant_type = "client_credential";
    private static String appid = "wx1e8c4fbe99878dc6";
    private static String secret = "4c6ab4d5d4520528bfa13c8d1d5b0a8d";

    private volatile String accessToken = "";

    public void init() {
        requestAccessToken();
        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(() -> {
            requestAccessToken();
        }, 30, 30, TimeUnit.MINUTES);
    }

    private void requestAccessToken() {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://www.corrine.com.cn:8090").path("cgi-bin/token");

        Form form = new Form();
        form.param("grant_type", grant_type);
        form.param("appid", appid);
        form.param("secret", secret);

        Response response = target.queryParam("grant_type", grant_type).queryParam("appid", appid)
                .queryParam("secret", secret).request().get();

        String bean = response.readEntity(String.class);
        System.out.println(bean);

        JsonValue jsonValue = JsonUtil.toJson(bean);
        JsonObject jsonObject = jsonValue.asJsonObject();

        JsonValue access_tokenJsonValue = jsonObject.get("access_token");
        String accessToken0 = String.valueOf(access_tokenJsonValue);
        accessToken = accessToken0.substring(1, accessToken0.length() - 1);
    }

    public String getAccessToken() {
        return accessToken;
    }

}
