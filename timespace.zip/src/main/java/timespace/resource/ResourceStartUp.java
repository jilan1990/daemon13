package timespace.resource;

import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import timespace.Test;
import timespace.miniprogram.MiniProgramResource;
import timespace.miniprogram.NoteMPResource;
import timespace.publicnumber.PNOpenIDResource;
import timespace.publicnumber.PublicNumberResource;

public class ResourceStartUp {

    private static final URI BASE_URI = URI.create("http://localhost:8080/wx/");

    public void init() {
        try {
            System.out.println("\"Hello World\" Jersey Example App");

            final HttpServer server = GrizzlyHttpServerFactory.createHttpServer(BASE_URI, create(), false);

            Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
                @Override
                public void run() {
                    server.shutdownNow();
                }
            }));
            server.start();

            System.out.println(
                    String.format("Application started.%n" + "Try out %s%n" + "Stop the application using CTRL+C",
                            BASE_URI));

            Thread.currentThread().join();
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Create example application resource configuration.
     *
     * @return initialized resource configuration of the example application.
     */
    public ResourceConfig create() {
        ResourceConfig resourceConfig = new ResourceConfig();

        // 通过微信公众号event， 收集openid, 然后调用api获取unionID,缓存下来
        resourceConfig.registerResources(new PublicNumberResource().getResource());
        resourceConfig.registerResources(new PNOpenIDResource().getResource());

        resourceConfig.registerResources(new MiniProgramResource().getResource());
        resourceConfig.registerResources(new NoteMPResource().getResource());

        return resourceConfig;
    }

}
