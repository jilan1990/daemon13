package timespace.resource;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Response;

@FunctionalInterface
public interface MethodAction {

    Response apply(ContainerRequestContext context);

}
