package timespace.resource;

public class Constants {

    public static final String METHOD_PUT = "PUT";

    public static final String METHOD_POST = "POST";

    public static final String METHOD_GET = "GET";

    // do not support entity body
    public static final String METHOD_DELETE = "DELETE";

    public static final String NOTE_REDIS_ID = "NOTE_REDIS_ID";

    public static final String NOTE_REDIS_MSG = "NOTE_REDIS_MSG";

    public static final String REDIS_IP = "118.24.189.188";

    public static final int REDIS_PORT = 16379;

    public static final String REDIS_AUTH = "polaris";
}
