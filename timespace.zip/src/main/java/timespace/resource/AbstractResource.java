package timespace.resource;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.process.Inflector;
import org.glassfish.jersey.server.model.Resource;

public abstract class AbstractResource {

    private Map<String, MethodAction> methodActions = new HashMap<String, MethodAction>();

    public Resource getResource() {
        String rootPath = getRootPath();
        final Resource.Builder resourceBuilder = Resource.builder(rootPath);

        Inflector<ContainerRequestContext, Response> noContentResponder = new Inflector<ContainerRequestContext, Response>() {
            @Override
            public Response apply(ContainerRequestContext data) {
                return Response.noContent().build();
            }
        };
        resourceBuilder.addMethod("HEAD").handledBy(noContentResponder);
        resourceBuilder.addMethod("OPTIONS").handledBy(noContentResponder);

        MediaType[] mediaTypes = { MediaType.APPLICATION_JSON_TYPE, MediaType.TEXT_XML_TYPE };

        for (Map.Entry<String, MethodAction> entry : methodActions.entrySet()) {
            resourceBuilder.addMethod(entry.getKey()).consumes(mediaTypes).produces(mediaTypes)
                    .handledBy(new Inflector<ContainerRequestContext, Response>() {
                @Override
                public Response apply(ContainerRequestContext data) {
                    return entry.getValue().apply(data);
                }
            });
        }

        return resourceBuilder.build();
    }

    protected abstract String getRootPath();

    public void addMethodAction(String methodName, MethodAction methodAction) {
        methodActions.put(methodName, methodAction);
    }
}
