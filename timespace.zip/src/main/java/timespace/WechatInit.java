package timespace;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.core.Response;

import org.glassfish.json.JsonUtil;

public class WechatInit {

    @POST
    @Consumes("application/json")
    public Response postForm(String param) {
        System.out.println(param);
        JsonValue jsonValue = JsonUtil.toJson(param);
        JsonObject jsonObject = jsonValue.asJsonObject();
        return Response.ok("Hello World!").build();
    }

    @GET
    @Consumes("application/json")
    public Response getForm() {
        return Response.ok("Hello World!").build();
    }
}
