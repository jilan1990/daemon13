package timespace.tlssmssvr;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import com.alibaba.fastjson.JSON;
import com.github.qcloudsms.SmsSenderUtil;

public class SendSMS {

    public static void main(String[] args) {

        String strMobile = "15005182943"; // tel 的 mobile 字段的内容
        String sdkappid = "1400173129";
        String strAppKey = "9733fb4cdc9840c88ff2dd7e79daf55d"; // sdkappid 对应的 appkey，需要业务方高度保密
        
        long ts = System.currentTimeMillis();
        String strRand = String.valueOf(ts); // url 中的 random 字段的值

        String strTime = String.valueOf(ts / 1000); // UNIX 时间戳

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://127.0.0.1:7373").path("v5/tlssmssvr/sendsms");

        target = target.queryParam("sdkappid", sdkappid);
        target = target.queryParam("random", strRand);

        Map<String, Object> entity = new HashMap<String, Object>();
        entity.put("ext", "");
        entity.put("extend", "");

        List<String> params = new ArrayList<String>();
        params.add("验证码");
        params.add("1234");
        params.add("4");
        entity.put("params", params);

        String sig = SmsSenderUtil.calculateSignature(strAppKey, ts / 1000, ts, strMobile);
        entity.put("sig", sig);
        entity.put("sign", "腾讯云");

        Map<String, Object> tel = new HashMap<String, Object>();
        tel.put("mobile", strMobile);
        tel.put("nationcode", "86");
        entity.put("tel", tel);

        entity.put("time", ts / 1000);
        entity.put("tpl_id", 19);
        System.out.println(JSON.toJSONString(entity));

        String bean = target.request(MediaType.APPLICATION_JSON_TYPE)
                .post(Entity.entity(entity, MediaType.APPLICATION_JSON), String.class);
        System.out.println("getCode2Session:" + bean);
    }

    public static String getSHA256(String str) {
        MessageDigest messageDigest;
        String encodestr = "";
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(str.getBytes("UTF-8"));
            encodestr = byte2Hex(messageDigest.digest());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return encodestr;
    }

    private static String byte2Hex(byte[] bytes) {
        StringBuffer stringBuffer = new StringBuffer();
        String temp = null;
        for (int i = 0; i < bytes.length; i++) {
            temp = Integer.toHexString(bytes[i] & 0xFF);
            if (temp.length() == 1) {
                // 1得到一位的进行补0操作
                stringBuffer.append("0");
            }
            stringBuffer.append(temp);
        }
        return stringBuffer.toString();
    }
}
