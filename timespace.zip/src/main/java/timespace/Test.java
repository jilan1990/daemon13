package timespace;

import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.process.Inflector;
import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.model.Resource;
import org.glassfish.json.JsonUtil;

import timespace.wechatapi.Code2Session;

public class Test {

    private static final URI BASE_URI = URI.create("http://localhost:8080/wx/");
    /**
     * "Hello World" root resource path.
     */
    public static final String ROOT_PATH = "helloworld";

    public static void main(String[] args) {
        try {
            System.out.println("\"Hello World\" Jersey Example App");

            final HttpServer server = GrizzlyHttpServerFactory.createHttpServer(BASE_URI, create(), false);

            Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
                @Override
                public void run() {
                    server.shutdownNow();
                }
            }));
            server.start();

            System.out.println(
                    String.format("Application started.%n" + "Try out %s%s%n" + "Stop the application using CTRL+C",
                            BASE_URI, ROOT_PATH));

            Thread.currentThread().join();
        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * Test assertion indicator that a GET method handler has been called.
     */
    public static volatile boolean getMethodCalled = false;
    /**
     * Test assertion indicator that a HEAD method handler has been called.
     */
    public static volatile boolean headMethodCalled = false;

    /**
     * Create example application resource configuration.
     *
     * @return initialized resource configuration of the example application.
     */
    public static ResourceConfig create() {
        final Resource.Builder resourceBuilder = Resource.builder(ROOT_PATH);

        resourceBuilder.addMethod("POST").consumes(MediaType.APPLICATION_JSON_TYPE)
                .produces(MediaType.APPLICATION_JSON_TYPE)
                .handledBy(new Inflector<ContainerRequestContext, Response>() {

            @Override
            public Response apply(ContainerRequestContext request) {
                getMethodCalled = true;

                String data = (request != null) ? ((ContainerRequest) request).readEntity(String.class) : null;

                        System.out.println("data:" + data);
                        JsonValue jsonValue = JsonUtil.toJson(data);
                        JsonObject jsonObject = jsonValue.asJsonObject();

                        JsonValue logincodeJsonValue = jsonObject.get("logincode");
                        String logincode0 = String.valueOf(logincodeJsonValue);
                        String logincode = logincode0.substring(1, logincode0.length() - 1);

                        System.out.println("logincode:" + logincode);
                        String code2Session = String.valueOf(Code2Session.getCode2Session(logincode));
                        System.out.println("code2Session:" + code2Session);
                        System.out.println();

                return Response.ok("Hello World!").build();
            }
        });

        Inflector<ContainerRequestContext, Response> noContentResponder = new Inflector<ContainerRequestContext, Response>() {

            @Override
            public Response apply(ContainerRequestContext data) {
                headMethodCalled = true;
                return Response.noContent().build();
            }
        };
        resourceBuilder.addMethod("HEAD").handledBy(noContentResponder);
        resourceBuilder.addMethod("OPTIONS").handledBy(noContentResponder);

        return new ResourceConfig().registerResources(resourceBuilder.build());
    }

}
