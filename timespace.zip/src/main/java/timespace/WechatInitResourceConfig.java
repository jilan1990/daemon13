package timespace;

import javax.ws.rs.Path;

import org.glassfish.jersey.server.ResourceConfig;

@Path("clipboard")
public class WechatInitResourceConfig extends ResourceConfig {
    public WechatInitResourceConfig() {
        registerClasses(WechatInit.class);
    }
}
