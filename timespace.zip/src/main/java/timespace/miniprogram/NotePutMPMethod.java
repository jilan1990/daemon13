package timespace.miniprogram;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.json.JsonUtil;

import timespace.note.NoticeMessageMaster;
import timespace.resource.MethodAction;

public class NotePutMPMethod implements MethodAction {

    @Override
    public Response apply(ContainerRequestContext context) {
        String data = (context != null) ? ((ContainerRequest) context).readEntity(String.class) : null;

        System.out.println("data:" + data);
        JsonValue jsonValue = JsonUtil.toJson(data);
        JsonObject jsonObject = jsonValue.asJsonObject();

        JsonValue unionidJsonValue = jsonObject.get("unionid");
        if (unionidJsonValue == null) {
            return Response.ok("Hello World!").build();
        }
        String unionid0 = String.valueOf(unionidJsonValue);
        String unionid = unionid0.substring(1, unionid0.length() - 1);

        JsonValue timesJsonValue = jsonObject.get("times");
        String times0 = String.valueOf(timesJsonValue);
        String times = times0.substring(1, times0.length() - 1);

        JsonValue datesJsonValue = jsonObject.get("dates");
        String dates0 = String.valueOf(datesJsonValue);
        String dates = dates0.substring(1, dates0.length() - 1);

        JsonValue periodJsonValue = jsonObject.get("period");
        String period0 = String.valueOf(periodJsonValue);
        String period = period0.substring(1, period0.length() - 1);

        // TODO check validate
        JsonValue remarkJsonValue = jsonObject.get("remark");
        String remark0 = String.valueOf(remarkJsonValue);
        String remark = remark0.substring(1, remark0.length() - 1);

        // 1986/07/03 00:00:00|60000
        String[] datess = dates.split("-");
        String[] timess = times.split(":");
        Integer year = Integer.parseInt(datess[0]);
        Integer month = Integer.parseInt(datess[1]) - 1;
        Integer day = Integer.parseInt(datess[2]);

        Integer hour = Integer.parseInt(timess[0]);
        Integer minute = Integer.parseInt(timess[1]);

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day, hour, minute);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String date = sdf.format(calendar.getTime());
        System.out.println(date + "|" + period);

        String periodStr = "0";
        switch (period) {
        case "day":
        case "week":
        case "month":
        case "year":
            periodStr = period;
            break;
        default:
            try {
                Long periodLong = Long.parseLong(period);
                periodStr = String.valueOf(periodLong);
            } catch (NumberFormatException e) {
                periodStr = null;
                e.printStackTrace();
            }
            break;
        }
        if (periodStr != null) {
            String params = date + "|" + periodStr;

            Map<String, String> note = new HashMap<String, String>();
            note.put("params", params);
            note.put("unionid", unionid);
            note.put("title", remark);

            NoticeMessageMaster.getInstance().add(note);
        }

        return Response.ok("Hello World!").build();
    }

}
