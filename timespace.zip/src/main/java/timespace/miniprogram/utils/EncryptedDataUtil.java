package timespace.miniprogram.utils;

import java.security.AlgorithmParameters;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class EncryptedDataUtil {

    String encryptedData = "4smXw2sJmP766B7ZVd1dTMRAwGpgp9DABR2NcxQg969zJGF8532yLPUbR+Mse4m6h3y5aC5xvd5wqYKhllARz4R+dK+L0UyeOKCQ5PXekRsX01T1PZ3Bv5MV9ygiQaASVobatul8hmiaAsxKyhd01g0lk1Ue6VzedZ9//hoQmiNF10Pk+4rFm4eUa7I8hxNDGoBLi0d4txvPl1QYwqiTHqNeDo4WzqTWiiPLNHbYww97IinHTgI6nsZRb74Nn2v7WgUsYyAN7KOqAjQdX7JUScWteC1aGffDOiA2mLDA31JYpRQ46JBCdM9SiZ11BLIr/et2ykrRjsvkEtvuf1y2BNWfaffZzdwI7F2C/4nUg6yf8WZsdqCZXJfL3BzXoaIjdqDhS4tEraxbgit2KI4fuoi9Bzqj8CIbTFOO7OvCD9euXuQt9lgEo/SUN2nxK9EMnmQJaXGRBJoWkZJly40zDvW7TXrpU9N2QruEq9iSU2fA28Towiq2FyBLSTcTaAzp";
    String session_key = "DR5RRojvDNL30ucFJL4Ebg==";
    String iv = "Hw6DYi3QE0Smr3yHq3dxsA==";

    public static String decrypt(String encryptedData, String session_key, String iv) {

        byte[] dataByteArray = Base64.decodeBase64(encryptedData);
        byte[] keyByte = Base64.decodeBase64(session_key);
        byte[] ivByte = Base64.decodeBase64(iv);

        int base = 16;
        if (keyByte.length % base != 0) {
            int groups = keyByte.length / base + (keyByte.length % base != 0 ? 1 : 0);
            byte[] temp = new byte[groups * base];
            Arrays.fill(temp, (byte) 0);
            System.arraycopy(keyByte, 0, temp, 0, keyByte.length);
            keyByte = temp;
        }

        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
        try {
            AlgorithmParameters params = AlgorithmParameters.getInstance("AES");
            params.init(new IvParameterSpec(ivByte));

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding", "BC");
            Key sKeySpec = new SecretKeySpec(keyByte, "AES");
            cipher.init(Cipher.DECRYPT_MODE, sKeySpec, params);// 初始化
            byte[] decrypted = cipher.doFinal(dataByteArray);

            int pad = decrypted[decrypted.length - 1];
            String s = new String(decrypted);
            return s;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
}
