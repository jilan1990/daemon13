package timespace.miniprogram;

import timespace.resource.AbstractResource;
import timespace.resource.Constants;

public class NoteMPResource extends AbstractResource {

    public NoteMPResource() {
        addMethodAction(Constants.METHOD_GET, new NoteDeleteMPMethod());
        addMethodAction(Constants.METHOD_PUT, new NotePutMPMethod());
        addMethodAction(Constants.METHOD_POST, new NotePostMPMethod());
    }

    @Override
    protected String getRootPath() {
        return "mpnote";
    }

}
