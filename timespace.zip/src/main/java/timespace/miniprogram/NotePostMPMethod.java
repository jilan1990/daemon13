package timespace.miniprogram;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.json.JsonUtil;

import timespace.note.NoticeMessageMaster;
import timespace.resource.MethodAction;

public class NotePostMPMethod implements MethodAction {

    @Override
    public Response apply(ContainerRequestContext context) {
        String data = (context != null) ? ((ContainerRequest) context).readEntity(String.class) : null;

        System.out.println("data:" + data);
        JsonValue jsonValue = JsonUtil.toJson(data);
        JsonObject jsonObject = jsonValue.asJsonObject();

        JsonValue unionidJsonValue = jsonObject.get("unionid");
        String unionid0 = String.valueOf(unionidJsonValue);
        String unionid = unionid0.substring(1, unionid0.length() - 1);

        Map<String, Map<String, String>> notes = NoticeMessageMaster.getInstance().getNoteByUnionid(unionid);

        List<Map<String, String>> result = new ArrayList<Map<String, String>>();
        for (Map.Entry<String, Map<String, String>> entry : notes.entrySet()) {
            Map<String, String> note = entry.getValue();

            String params = note.get("params");
            String[] paramss = params.split("\\|");

            Map<String, String> map = new HashMap<String, String>();
            map.put("id", note.get("id"));
            map.put("date", paramss[0]);
            map.put("period", paramss[1]);
            map.put("remark", note.get("title"));

            result.add(map);
        }

        Collections.sort(result, new Comparator<Map>() {
            @Override
            public int compare(Map o1, Map o2) {
                String dateStr1 = (String) o1.get("date");
                String dateStr2 = (String) o2.get("date");

                long ts1 = getTs(dateStr1);
                long ts2 = getTs(dateStr2);
                long sub = ts1 - ts2;
                return sub > 0 ? 1 : (sub == 0 ? 0 : -1);
            }

            private long getTs(String date) {
                String[] ss = date.split(" ");
                String[] dates = ss[0].split("/");
                String[] timess = ss[1].split(":");
                Integer year = Integer.parseInt(dates[0]);
                Integer month = Integer.parseInt(dates[1]) - 1;
                Integer day = Integer.parseInt(dates[2]);

                Integer hour = Integer.parseInt(timess[0]);
                Integer minute = Integer.parseInt(timess[1]);

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day, hour, minute, 0);
                long ts = calendar.getTime().getTime();
                ts = ts / 1000 * 1000;
                return ts;
            }
        });

        return Response.ok(result).build();
    }

}
