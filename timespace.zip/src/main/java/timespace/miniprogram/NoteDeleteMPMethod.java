package timespace.miniprogram;

import java.util.List;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import timespace.note.NoticeMessageMaster;
import timespace.resource.MethodAction;

public class NoteDeleteMPMethod implements MethodAction {

    @Override
    public Response apply(ContainerRequestContext context) {

        UriInfo uriInfo = context.getUriInfo();
        MultivaluedMap<String, String> datas = uriInfo.getQueryParameters();
        System.out.println("data:" + datas);

        List<String> unionids = datas.get("unionid");
        String unionid = unionids.get(0);

        List<String> ids = datas.get("id");
        String id = ids.get(0);

        NoticeMessageMaster.getInstance().remove(unionid, id);

        return Response.ok("Hello World!").build();
    }

}
