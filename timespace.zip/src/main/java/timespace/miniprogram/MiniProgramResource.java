package timespace.miniprogram;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.server.ContainerRequest;
import org.glassfish.json.JsonUtil;

import timespace.miniprogram.utils.EncryptedDataUtil;
import timespace.resource.AbstractResource;
import timespace.resource.Constants;
import timespace.wechatapi.Code2Session;

public class MiniProgramResource extends AbstractResource {

    public MiniProgramResource() {
        addMethodAction(Constants.METHOD_POST, (context) -> {

            String data = (context != null) ? ((ContainerRequest) context).readEntity(String.class) : null;

            System.out.println("mp.data:" + data);
            JsonValue jsonValue = JsonUtil.toJson(data);
            JsonObject jsonObject = jsonValue.asJsonObject();

            JsonValue logincodeJsonValue = jsonObject.get("logincode");
            String logincode0 = String.valueOf(logincodeJsonValue);
            String logincode = logincode0.substring(1, logincode0.length() - 1);

            JsonValue ivJsonValue = jsonObject.get("iv");
            String iv0 = String.valueOf(ivJsonValue);
            String iv = iv0.substring(1, iv0.length() - 1);

            String code2Session = Code2Session.getCode2Session(logincode);
            JsonValue code2SessionJsonValue = JsonUtil.toJson(code2Session);
            JsonObject code2SessionJsonObject = code2SessionJsonValue.asJsonObject();

            JsonValue session_keyJsonValue = code2SessionJsonObject.get("session_key");
            String session_key0 = String.valueOf(session_keyJsonValue);
            String session_key = session_key0.substring(1, session_key0.length() - 1);
            System.out.println("session_key:" + session_key);

            JsonValue encryptedDataJsonValue = jsonObject.get("encryptedData");
            String encryptedData0 = String.valueOf(encryptedDataJsonValue);
            String encryptedData = encryptedData0.substring(1, encryptedData0.length() - 1);

            String decryptStr = EncryptedDataUtil.decrypt(encryptedData, session_key, iv);
            System.out.println("decryptStr:" + decryptStr);

            JsonValue decryptStrJsonValue = JsonUtil.toJson(decryptStr);
            JsonObject decryptStrJsonObject = decryptStrJsonValue.asJsonObject();

            JsonValue unionIdJsonValue = decryptStrJsonObject.get("unionId");
            String unionId0 = String.valueOf(unionIdJsonValue);
            String unionId = unionId0.substring(1, unionId0.length() - 1);

            System.out.println(unionId);

            return Response.ok(unionId).build();
        });
    }

    @Override
    protected String getRootPath() {
        return "mp";
    }

}
