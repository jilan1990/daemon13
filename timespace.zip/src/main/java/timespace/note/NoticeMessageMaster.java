package timespace.note;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.fastjson.JSON;

import redis.clients.jedis.Jedis;
import timespace.resource.Constants;
import timespace.utils.YamlUtil;

public class NoticeMessageMaster {

    private static final NoticeMessageMaster INSTANCE = new NoticeMessageMaster();

    private NoticeMessageMaster() {
    }

    public static NoticeMessageMaster getInstance() {
        return INSTANCE;
    }

    private final String PATH = "note";
    private Map<String, Map<String, Map<String, String>>> notes = new ConcurrentHashMap<String, Map<String, Map<String, String>>>();

    public void init() {
        File file = new File(PATH);
        String[] unionids = file.list();
        if (unionids == null) {
            return;
        }
        for (String unionid : unionids) {
            File openidFile = new File(file, unionid);
            String[] notess = openidFile.list();
            if (notess == null) {
                continue;
            }

            for (String notename : notess) {
                File noteFile = new File(openidFile, notename);
                Map note = YamlUtil.getYamlObj(noteFile.getAbsolutePath());

                Map<String, Map<String, String>> paramsNotes = notes.get(unionid);
                if (paramsNotes == null) {
                    paramsNotes = new ConcurrentHashMap<String, Map<String, String>>();
                    notes.put(unionid, paramsNotes);
                }
                String id = (String) note.get("id");
                paramsNotes.put(id, note);
            }
        }
    }

    public void add(Map<String, String> note) {

        String unionid = note.get("unionid");
        if (unionid == null) {
            return;
        }

        try (Jedis jedis = new Jedis(Constants.REDIS_IP, Constants.REDIS_PORT);) {
            jedis.auth(Constants.REDIS_AUTH);

            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            String date = sdf.format(calendar.getTime());

            String noteID = date + "_" + jedis.incr(Constants.NOTE_REDIS_ID);
            note.put("id", noteID);

            String path = PATH + "/" + unionid;
            String filename = noteID + ".yaml";
            YamlUtil.createYamlFile(path, filename, note);

            note.put("type", "add");

            jedis.lpush(Constants.NOTE_REDIS_MSG, JSON.toJSONString(note));

            Map<String, Map<String, String>> paramsNotes = notes.get(unionid);
            if (paramsNotes == null) {
                paramsNotes = new ConcurrentHashMap<String, Map<String, String>>();
                notes.put(unionid, paramsNotes);
            }
            paramsNotes.put(noteID, note);

        }

    }

    public Map<String, Map<String, String>> getNoteByUnionid(String unionid) {
        Map<String, Map<String, String>> result = new HashMap<String, Map<String, String>>();
        if (!notes.containsKey(unionid)) {
            return result;
        }
        result.putAll(notes.get(unionid));
        return result;
    }

    public void remove(String unionid, String id) {

        Map<String, String> note = new HashMap<String, String>();
        note.put("type", "delete");
        note.put("unionid", unionid);
        note.put("id", id);

        try (Jedis jedis = new Jedis(Constants.REDIS_IP, Constants.REDIS_PORT);) {
            jedis.auth(Constants.REDIS_AUTH);
            jedis.lpush(Constants.NOTE_REDIS_MSG, JSON.toJSONString(note));
        }

        String path = PATH + "/" + unionid;
        String filename = id + ".yaml";
        File file = new File(path, filename);
        if (file.exists()) {
            file.delete();
        }

        Map<String, Map<String, String>> paramsNotes = notes.get(unionid);
        if (paramsNotes == null) {
            return;
        }
        paramsNotes.remove(id);
    }

}
