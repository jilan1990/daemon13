package timespace.wechatapi;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;

public class Code2Session {

    private static String grant_type = "authorization_code";
    private static String appid = "wxf0892a7b2a7daab3";
    private static String secret = "a4c1908491994f574f6017507aa0190a";

    public static void main(String[] args) {

        String js_code = "";
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://www.corrine.com.cn:8090").path("sns/jscode2session?grant_type="
                + grant_type + "&appid=" + appid + "&secret=" + secret + "&js_code" + js_code);

        System.out.println("http://www.corrine.com.cn:8090" + "/sns/jscode2session?grant_type=" + grant_type + "&appid="
                + appid + "&secret=" + secret + "&js_code=" + js_code);
        Form form = new Form();
        form.param("grant_type", grant_type);
        form.param("appid", appid);
        form.param("secret", secret);
        form.param("js_code", js_code);

        String bean = target.request(MediaType.APPLICATION_JSON_TYPE).get(String.class);
        // .get(Entity.entity(form, MediaType.APPLICATION_JSON), String.class);
        System.out.println(bean);
    }

    public static String getCode2Session(String js_code) {

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://www.corrine.com.cn:8090").path("sns/jscode2session");

        Form form = new Form();
        form.param("grant_type", grant_type);
        form.param("appid", appid);
        form.param("secret", secret);
        form.param("js_code", js_code);

        String bean = target.request(MediaType.APPLICATION_JSON_TYPE)
                .post(Entity.entity(form, MediaType.APPLICATION_JSON), String.class);
        System.out.println("getCode2Session:" + bean);
        return bean;
    }

}
