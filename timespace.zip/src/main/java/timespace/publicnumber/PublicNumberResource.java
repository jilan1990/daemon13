package timespace.publicnumber;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.glassfish.jersey.server.ContainerRequest;

import timespace.resource.AbstractResource;
import timespace.resource.Constants;

public class PublicNumberResource extends AbstractResource {

    public PublicNumberResource() {
        addMethodAction(Constants.METHOD_POST, (context) -> {

            String data = (context != null) ? ((ContainerRequest) context).readEntity(String.class) : null;
            System.out.println("data:" + data);


            try {
                Document doc = DocumentHelper.parseText(data);
                Element rootElt = doc.getRootElement();

                Element msgTypeElement = rootElt.element("MsgType");
                switch (msgTypeElement.getText()) {
                case "event":
                    executeEvent(rootElt);
                    break;
                default:
                    break;
                }

                Element toUserName = rootElt.element("ToUserName");
                System.out.println(toUserName.getText());
            } catch (DocumentException e) {
                e.printStackTrace();
            }

            return Response.ok(String.valueOf(data)).build();
        });
        addMethodAction(Constants.METHOD_GET, (context) -> {
            UriInfo uriInfo = context.getUriInfo();
            MultivaluedMap<String, String> datas = uriInfo.getQueryParameters();
            System.out.println("data:" + datas);
            List<String> echostrs = datas.get("echostr");

            return Response.ok(String.valueOf(echostrs.get(0))).build();
        });
    }

    private Document executeEvent(Element rootElt) {
        Document result = DocumentHelper.createDocument();

        Element toUserNameElement = rootElt.element("ToUserName");
        String toUserName = toUserNameElement.getText();
        System.out.println(toUserName);

        Element fromUserNameElement = rootElt.element("FromUserName");
        String fromUserName = fromUserNameElement.getText();

        String unionID = PublicNumberUnionID.getUnionID(fromUserName);

        if (unionID == null) {
            return result;
        }

        System.out.println(unionID);

        Map<String, String> obj = new HashMap<String, String>();
        obj.put("unionid", unionID);
        obj.put("openid", fromUserName);
        obj.put("wechatid", toUserName);

        PNUnionIDMaster.getInstance().add(obj);

        return result;
    }

    @Override
    protected String getRootPath() {
        return "pn";// PublicNumber
    }

}
