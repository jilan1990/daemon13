package timespace.publicnumber.menu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import redis.clients.jedis.Jedis;
import timespace.resource.Constants;

public class Menu {

    public static void main(String[] args) {
        // https://api.weixin.qq.com/cgi-bin/menu/get?access_token=ACCESS_TOKEN
        delete();
        create();
        get();
    }

    private static void create() {

        try (Jedis jedis = new Jedis(Constants.REDIS_IP, Constants.REDIS_PORT);) {
            jedis.auth(Constants.REDIS_AUTH);

            String accessToken = jedis.get("accessToken");

            Client client = ClientBuilder.newClient();
            WebTarget target = client.target("http://www.corrine.com.cn:8090").path("cgi-bin/menu/create");

            Map<String, Object> jsonMap = new HashMap<String, Object>();

            List<Object> button = new ArrayList<Object>();

            Map<String, Object> obj = new HashMap<String, Object>();
            obj.put("type", "miniprogram");
            obj.put("name", "时空");
            obj.put("url", "http://www.corrine.com.cn");
            obj.put("appid", "wxf0892a7b2a7daab3");
            obj.put("pagepath", "/pages/index/index");
            
            button.add(obj);

            jsonMap.put("button", button);

            String bean = target.queryParam("access_token", accessToken).request(MediaType.APPLICATION_JSON_TYPE)
                    .post(Entity.entity(jsonMap, MediaType.APPLICATION_JSON), String.class);

            System.out.println(bean);
        }
    }

    private static void delete() {

        try (Jedis jedis = new Jedis(Constants.REDIS_IP, Constants.REDIS_PORT);) {
            jedis.auth(Constants.REDIS_AUTH);

            String accessToken = jedis.get("accessToken");

            Client client = ClientBuilder.newClient();
            WebTarget target = client.target("http://www.corrine.com.cn:8090").path("cgi-bin/menu/delete");

            Response response = target.queryParam("access_token", accessToken).request().get();

            String bean = response.readEntity(String.class);
            System.out.println(bean);
        }
    }

    private static void get() {

        try (Jedis jedis = new Jedis(Constants.REDIS_IP, Constants.REDIS_PORT);) {
            jedis.auth(Constants.REDIS_AUTH);

            String accessToken = jedis.get("accessToken");

            Client client = ClientBuilder.newClient();
            WebTarget target = client.target("http://www.corrine.com.cn:8090").path("cgi-bin/menu/get");

            Response response = target.queryParam("access_token", accessToken).request().get();

            String bean = response.readEntity(String.class);
            System.out.println(bean);
        }
    }
}
