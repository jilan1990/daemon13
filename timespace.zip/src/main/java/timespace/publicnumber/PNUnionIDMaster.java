package timespace.publicnumber;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import timespace.utils.YamlUtil;

public class PNUnionIDMaster {

    private static final PNUnionIDMaster INSTANCE = new PNUnionIDMaster();

    private PNUnionIDMaster() {
    }

    public static PNUnionIDMaster getInstance() {
        return INSTANCE;
    }

    final String path = "publicnumber";

    Map<String, String> unionid2openid = new HashMap<String, String>();
    Map<String, Map<String, String>> unionid2Obj = new HashMap<String, Map<String, String>>();

    public void init() {
        File dir = new File(path);
        String[] wechatids = dir.list();
        for (String wechatid : wechatids) {
            File wechatidFile = new File(dir, wechatid);
            String[] unionidYamls = wechatidFile.list();

            for (String unionidYaml : unionidYamls) {
                Map obj = YamlUtil.getYamlObj(wechatidFile + "/" + unionidYaml);
                String openid = (String) obj.get("openid");
                String unionid = (String) obj.get("unionid");
                unionid2openid.put(unionid, openid);

                unionid2Obj.put(unionid, obj);
            }
        }
    }

    public void add(Map<String, String> obj) {

        String openid = obj.get("openid");
        String wechatid = obj.get("wechatid");
        String unionid = obj.get("unionid");

        unionid2openid.put(unionid, openid);

        unionid2Obj.put(unionid, obj);

        String filename = unionid + ".yaml";

        File dir = new File(path, wechatid);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        try {
            YamlUtil.createYamlFile(dir.getCanonicalPath(), filename, obj);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getOpenIDByUnionID(String unionid) {
        return unionid2openid.get(unionid);
    }

    public Map<String, String> getOpenIDObjByUnionID(String unionid) {
        return unionid2Obj.get(unionid);
    }
}
