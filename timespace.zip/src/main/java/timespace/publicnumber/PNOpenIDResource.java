package timespace.publicnumber;

import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import com.alibaba.fastjson.JSON;

import timespace.resource.AbstractResource;
import timespace.resource.Constants;

public class PNOpenIDResource extends AbstractResource {

    public PNOpenIDResource() {

        addMethodAction(Constants.METHOD_GET, (context) -> {
            UriInfo uriInfo = context.getUriInfo();
            MultivaluedMap<String, String> datas = uriInfo.getQueryParameters();
            System.out.println("data:" + datas);
            List<String> unionids = datas.get("unionid");

            String result = null;
            if (unionids == null || unionids.isEmpty()) {
                return Response.ok(String.valueOf(result)).build();
            }

            String unionid = unionids.get(0);

            Map<String, String> obj = PNUnionIDMaster.getInstance().getOpenIDObjByUnionID(unionid);

            return Response.ok(JSON.toJSONString(obj)).build();
        });
    }


    @Override
    protected String getRootPath() {
        return "pnopenid";// PublicNumber
    }

}
