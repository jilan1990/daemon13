package timespace.publicnumber;

import redis.clients.jedis.Jedis;
import timespace.resource.Constants;

public class PublicNumberAccessTokenRedis {

    private static final PublicNumberAccessTokenRedis INSTANCE = new PublicNumberAccessTokenRedis();

    private PublicNumberAccessTokenRedis() {
    }

    public static PublicNumberAccessTokenRedis getInstance() {
        return INSTANCE;
    }

    public String getAccessToken() {
        try (Jedis jedis = new Jedis(Constants.REDIS_IP, Constants.REDIS_PORT);) {
            jedis.auth(Constants.REDIS_AUTH);
            return jedis.get("accessToken");
        }
    }

}
