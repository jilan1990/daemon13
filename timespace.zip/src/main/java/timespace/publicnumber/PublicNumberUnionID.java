package timespace.publicnumber;

import javax.json.JsonObject;
import javax.json.JsonValue;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.Response;

import org.glassfish.json.JsonUtil;

public class PublicNumberUnionID {

    public static String getUnionID(String openid) {

        String accessToken = PublicNumberAccessTokenRedis.getInstance().getAccessToken();

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://www.corrine.com.cn:8090").path("cgi-bin/user/info");

        Form form = new Form();
        form.param("access_token", accessToken);
        form.param("openid", openid);
        form.param("lang", "en");

        Response response = target.queryParam("access_token", accessToken).queryParam("openid", openid)
                .queryParam("lang", "en").request().get();

        String entity = response.readEntity(String.class);
        System.out.println(entity);

        JsonValue jsonValue = JsonUtil.toJson(entity);
        JsonObject jsonObject = jsonValue.asJsonObject();

        JsonValue unionidJsonValue = jsonObject.get("unionid");

        if (unionidJsonValue == null) {
            return null;
        }
        String unionid0 = String.valueOf(unionidJsonValue);

        String unionid = unionid0.substring(1, unionid0.length() - 1);

        return unionid;
    }

}
