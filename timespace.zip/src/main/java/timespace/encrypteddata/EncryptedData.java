package timespace.encrypteddata;


import org.apache.commons.codec.binary.Base64;

import com.sun.org.apache.xml.internal.security.exceptions.Base64DecodingException;

public class EncryptedData {

    public static void main(String[] args) {
        String encryptedData = "hGocMlX/L2SSLkfliU98gt+TulM7/d499kPSyctXx8g2rWuI26LHZE/iPwdiZHfXT3prNg+PmZ8nBn2PWRdHaRZy2jFGOyLrj1KK/9ifi8QKunGeC8Ea0RDgchAOlYBUNCU60rGqXn7yOW9VtDeYzdLifkghXli6Dvh9ihKY8pE7srqToajbDufgaYxwJbX46IjqazwWBpvCa62qaP+yPhYnFp0flM8YWZoPRwNmHu07yR9JhVkCZj5bBK0FkmlqGE64jFdt5fAmO/sbbCVaYiIhYYWcE/aw9ixHTMOWERGWwgLCeFuIdVbIEQSfOpUgGA2/ToVOLNToJnpcglXV/nPtrl6Nhq5Xalf4IH8AVAuwFYK+kLy5etnjGdFVDKnNm1spbKDisT1Zo9hoWhb2HnUfKxXlFMumugeoxCweCrUUFa1E3Xspe0kGnu4vaadiqh7G4rfP4tMnE7LNViMug2tqFxzHNrMUFofr0kI289EQ+L1zgdSWJQED1JPtdFYF";
//
//        byte[] dataByteArray = Base64.getDecoder().decode(encryptedData);
//        String data = new String(dataByteArray);
//        System.out.println(data);
        String session_key = "kh1+HyI\\/xzychOlndHK0zg==";

        byte[] keyBytes = Base64.decodeBase64(session_key);
        System.out.println(keyBytes == null ? null : keyBytes.length);
        System.out.println(new String(keyBytes == null ? null : keyBytes));
        System.out.println(new String(keyBytes == null ? null : keyBytes));

        System.out.println(new String(com.sun.org.apache.xerces.internal.impl.dv.util.Base64.decode(encryptedData)));

        System.out.println(new String(java.util.Base64.getDecoder().decode(encryptedData)));

        try {
            System.out.println(new String(com.sun.org.apache.xml.internal.security.utils.Base64.decode(encryptedData)));
        } catch (Base64DecodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
