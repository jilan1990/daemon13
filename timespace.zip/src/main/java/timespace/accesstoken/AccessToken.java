package timespace.accesstoken;

import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;

public class AccessToken {

    public static void main(String[] args) {
        String grant_type = "client_credential";
        String appid = "wx1e8c4fbe99878dc6";
        String secret = "fd5ed8be522f6873840f055945a5dd1c";
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=" + grant_type + "&appid=" + appid + "&secret="
                + secret;

        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://www.corrine.com.cn:8090").path("cgi-bin/token");

        Form form = new Form();
        form.param("grant_type", grant_type);
        form.param("appid", appid);
        form.param("secret", secret);

        Map bean = target.request(MediaType.APPLICATION_JSON_TYPE)
                .post(Entity.entity(form, MediaType.APPLICATION_FORM_URLENCODED_TYPE), Map.class);
        System.out.println(bean.get("access_token"));
        System.out.println(bean.get("expires_in"));

    }

}
