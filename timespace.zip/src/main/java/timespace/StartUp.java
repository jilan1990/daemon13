package timespace;

import timespace.note.NoticeMessageMaster;
import timespace.publicnumber.PNUnionIDMaster;
import timespace.resource.ResourceStartUp;

public class StartUp {

    public static void main(String[] args) {

        // PublicNumberAccessToken.getInstance().init();

        NoticeMessageMaster.getInstance().init();
        PNUnionIDMaster.getInstance().init();

        new ResourceStartUp().init();

    }

}
